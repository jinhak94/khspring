package com.kh.spring.menu.model.service;

import java.util.List;

import com.kh.spring.menu.model.vo.Menu;

public interface MenuService {

	List<Menu> selectMenuList();

}
